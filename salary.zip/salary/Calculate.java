package SalarySheet;

/**
 * Created by famed on 5/9/16.
 */
public class Calculate {

    public void calculate(int a,int b,int c){
        SalaryMainController slcal = new SalaryMainController();


    }
}
